/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package learn;

/**
 *
 * @author user
 */
public class learn_0 {
    public static void main(String[] args) {
        System.out.println("歡迎光臨");
        //learn_1.E01();learn_2.E02();
        //learn_3.初值();
        //learn_3.顯示();
        //learn_3.修改();
        //learn_3.顯示();
        //learn_4.設初值();
        //learn_4.顯示();
        learn_5.定初值();learn_5.顯示();
        
        
        
    }
    
}
