/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package learn;

/**
 *
 * @author user
 */
public class learn_2 {
    public static void E02(){
        System.out.println("英文成績");
        System.out.println(100);
        System.out.println("數學成績");
        System.out.println(99);
        System.out.println("總分");
        System.out.println(100+99);
    }
    
}
