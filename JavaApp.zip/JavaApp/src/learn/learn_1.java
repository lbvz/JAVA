/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package learn;

/**
 *
 * @author user
 */
public class learn_1 {
    public static void E01(){
        System.out.println("你好嗎");
    }
    
}
