/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package 計算;

/**
 *
 * @author user
 */
public class EX_01 {
  
    public static void main(String[] args) {
        //System.out.println("設定初始值");
        //System.out.println("--------------");
         //EX_02.顯示();
         //EX_03.初始值();
         //EX_03.顯示資料();
         //EX_03.評重();
         //EX_03.顯示資料();
         //EX_03.BMI檢測();
         //EX_04.跑流程();
         EX_05.跑程_1();
         EX_05.跑程_2();
         //EX_06.跑程_1_1();
         //EX_06.跑程_1_2();
         //EX_06.跑程_1_3();
         
         
         
         
         
         
         
        
        
        
  }
    
}
