/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc;

/**
 *
 * @author user
 */
public class num {public static void zzz(){
            System.out.println("英文");
            System.out.println(100);
            System.out.println("數學");
            System.out.println(99);
            System.out.println("總分");
            System.out.println(100+99);
            
            
}
    
}
