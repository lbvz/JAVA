/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc;

/**
 *
 * @author user
 */
public class abc {
    public static void main(String[] args) {
        System.out.println("歡迎進入");
        
        //def.pppp();
        //hij.uuu();
        //測試.qqq();
        num.zzz();
        
                
                
        
        
        
        
        
    }
    
}
